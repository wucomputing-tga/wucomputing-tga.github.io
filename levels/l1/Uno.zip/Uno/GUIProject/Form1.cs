﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUIProject
{
    public partial class Form1 : Form
    {
        //Stores the total deck of cards
        List<Card> deck = new List<Card>();

        //Stores the cards in the discard pile
        List<Card> discard = new List<Card>();

        //Stores the cards in the computer's hand
        List<Card> ai_cards = new List<Card>();

        //Stores the cards in the player's hand
        List<Card> hand = new List<Card>();

        public const int HAND_SIZE = 7;

        /// <summary>
        /// This is the constructor function for the class, it is executed when the form is created. Here we set up the initial display of the Uno card game. 
        /// </summary>
        public Form1()
        {
            InitializeComponent();
            deckPictureBox.Image = Image.FromFile("../../Cards/card_back_large.png");
            deckPictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            generateDeck();
            setupNewGame();
        }

        /// <summary>
        /// A method which adds a card object to our deck
        /// </summary>
        /// <param name="dir">The directory path to the card images.</param>
        /// <param name="colour">The colour of this card, valid options are: blue, green, yellow, red and wild.</param>
        /// <param name="type">The type of card, may be numbered, action or wild card.</param>
        /// <param name="amount">The number of cards of this type we would like to add to the deck.</param>
        private void addCard(string dir, string colour, string type, int amount)
        {
            Card new_card = new Card(dir + colour + "_" + type + "_large.png");
            for(int i = 0; i < amount; i++)
            {
                deck.Add(new_card);
            }
        }

        /// <summary>
        /// A method which generates a valid Uno card deck of 108 cards. 
        /// </summary>
        private void generateDeck()
        {
            //The path to where the card images are stored
            string dir = "../../Cards/";

            //An array to store the colours of the cards
            string[] colours = { "blue", "green", "yellow", "red" };

            //An array to store the names of the action cards 
            string[] action_cards = { "picker", "reverse", "skip" }; 

            //A loop to create all the cards in the various colours - there is one 0 card and two of each colour numbered 1-9 and 2 of every action card for each colour
            foreach(string colour in colours)
            {
                //Adding the zero card to the deck
                addCard(dir, colour, "0", 1);

                //Adding the numbered cards to the deck
                for(int i = 1; i < 10; i++)
                {
                    addCard(dir, colour, i.ToString(), 2);
                }

                //Adding the action cards to the deck
                foreach(string action in action_cards)
                {
                    addCard(dir, colour, action, 2);
                }
            }

            //Adding the wild cards to the deck, there are 4 of each
            addCard(dir, "wild", "colora_changer", 4);
            addCard(dir, "wild", "pick_four", 4);

            //Shuffle deck
            shuffleCards(deck);
        }


        /// <summary>
        /// Shuffle a given deck of cards.
        /// </summary>
        /// <param name="cards">Deck of cards to shuffle.</param>
        private void shuffleCards(List<Card> cards)
        {
            Random rand = new Random();

            //We will make the same number of shuffles as there are cards 
            for(int i = 0; i < cards.Count; i++)
            {
                //Get the two indexes of cards to swap
                int index = rand.Next(cards.Count);
                int index2 = rand.Next(cards.Count);

                //Temporarily store the card at index2 (so we don't lose it)
                Card temp = cards[index2];
                //Move the card at index 1 to index 2 position
                cards[index2] = cards[index];
                //Move the card that was at index 2 to index 1 position
                cards[index] = temp;
            }
        }

        /// <summary>
        /// Set up a new game for the AI and player
        /// </summary>
        public void setupNewGame()
        {
            Random rand = new Random();

            //Add a card from the deck to the discard pile
            Card starting = getCardFromDeck();
            discard.Add(starting);

            //Generate the AI player's hand
            generateHand(ai_cards);
            
            //Generate the user's hand
            generateHand(hand);

            //Display the cards on the form
            displayCards();

        }

        /// <summary>
        /// Generate a new hand for a player.
        /// </summary>
        /// <param name="cards">The player's hand.</param>
        private void generateHand(List<Card> cards)
        {
            for(int i = 0; i < HAND_SIZE; i++)
            {
                Card c = getCardFromDeck();
                cards.Add(c);
            }
        }

        /// <summary>
        /// Gets a random card from the deck.
        /// </summary>
        /// <returns>A random card.</returns>
        private Card getCardFromDeck()
        {
            Random rand = new Random();
            int index = rand.Next(deck.Count);
            Card c = deck[index];
            deck.RemoveAt(index);
            return c;
        }

        /// <summary>
        /// Display all the cards on the form.
        /// </summary>
        private void displayCards()
        {
            displayDiscard();
            displayPlayer();
        }
        
        /// <summary>
        /// Update the card that is displayed on the discard pile.
        /// </summary>
        private void displayDiscard()
        {
            discardPictureBox.Image = discard[0].card;
            discardPictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        /// <summary>
        /// Update the cards that are displayed to the player. 
        /// </summary>
        private void displayPlayer()
        {
            List<PictureBox> pictureBoxes = new List<PictureBox>() { handPictureBox1, handPictureBox2, handPictureBox3, handPictureBox4, handPictureBox5, handPictureBox6, handPictureBox7 };
            foreach(PictureBox p in pictureBoxes)
            {
                p.Image = null;
            }
            int size = HAND_SIZE;
            if (hand.Count < 7) size = hand.Count;
            for(int i = 0; i < size; i++)
            {
                pictureBoxes[i].Image = hand[i].card;
                pictureBoxes[i].SizeMode = PictureBoxSizeMode.StretchImage;
            }

        }
    }
}
