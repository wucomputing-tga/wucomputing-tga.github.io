﻿namespace GUIProject
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.deckPictureBox = new System.Windows.Forms.PictureBox();
            this.discardPictureBox = new System.Windows.Forms.PictureBox();
            this.handPictureBox1 = new System.Windows.Forms.PictureBox();
            this.labelHand = new System.Windows.Forms.Label();
            this.handPictureBox2 = new System.Windows.Forms.PictureBox();
            this.handPictureBox3 = new System.Windows.Forms.PictureBox();
            this.handPictureBox4 = new System.Windows.Forms.PictureBox();
            this.handPictureBox5 = new System.Windows.Forms.PictureBox();
            this.handPictureBox6 = new System.Windows.Forms.PictureBox();
            this.handPictureBox7 = new System.Windows.Forms.PictureBox();
            this.labelTurn = new System.Windows.Forms.Label();
            this.buttonLeft = new System.Windows.Forms.Button();
            this.buttonRight = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.deckPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.discardPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.handPictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.handPictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.handPictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.handPictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.handPictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.handPictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.handPictureBox7)).BeginInit();
            this.SuspendLayout();
            // 
            // deckPictureBox
            // 
            this.deckPictureBox.Location = new System.Drawing.Point(359, 46);
            this.deckPictureBox.Name = "deckPictureBox";
            this.deckPictureBox.Size = new System.Drawing.Size(119, 178);
            this.deckPictureBox.TabIndex = 0;
            this.deckPictureBox.TabStop = false;
            // 
            // discardPictureBox
            // 
            this.discardPictureBox.Location = new System.Drawing.Point(484, 46);
            this.discardPictureBox.Name = "discardPictureBox";
            this.discardPictureBox.Size = new System.Drawing.Size(119, 178);
            this.discardPictureBox.TabIndex = 1;
            this.discardPictureBox.TabStop = false;
            // 
            // handPictureBox1
            // 
            this.handPictureBox1.Location = new System.Drawing.Point(52, 245);
            this.handPictureBox1.Name = "handPictureBox1";
            this.handPictureBox1.Size = new System.Drawing.Size(119, 178);
            this.handPictureBox1.TabIndex = 2;
            this.handPictureBox1.TabStop = false;
            // 
            // labelHand
            // 
            this.labelHand.AutoSize = true;
            this.labelHand.Location = new System.Drawing.Point(49, 229);
            this.labelHand.Name = "labelHand";
            this.labelHand.Size = new System.Drawing.Size(59, 13);
            this.labelHand.TabIndex = 3;
            this.labelHand.Text = "Your hand:";
            // 
            // handPictureBox2
            // 
            this.handPictureBox2.Location = new System.Drawing.Point(177, 245);
            this.handPictureBox2.Name = "handPictureBox2";
            this.handPictureBox2.Size = new System.Drawing.Size(119, 178);
            this.handPictureBox2.TabIndex = 4;
            this.handPictureBox2.TabStop = false;
            // 
            // handPictureBox3
            // 
            this.handPictureBox3.Location = new System.Drawing.Point(302, 245);
            this.handPictureBox3.Name = "handPictureBox3";
            this.handPictureBox3.Size = new System.Drawing.Size(119, 178);
            this.handPictureBox3.TabIndex = 5;
            this.handPictureBox3.TabStop = false;
            // 
            // handPictureBox4
            // 
            this.handPictureBox4.Location = new System.Drawing.Point(427, 245);
            this.handPictureBox4.Name = "handPictureBox4";
            this.handPictureBox4.Size = new System.Drawing.Size(119, 178);
            this.handPictureBox4.TabIndex = 6;
            this.handPictureBox4.TabStop = false;
            // 
            // handPictureBox5
            // 
            this.handPictureBox5.Location = new System.Drawing.Point(552, 245);
            this.handPictureBox5.Name = "handPictureBox5";
            this.handPictureBox5.Size = new System.Drawing.Size(119, 178);
            this.handPictureBox5.TabIndex = 7;
            this.handPictureBox5.TabStop = false;
            // 
            // handPictureBox6
            // 
            this.handPictureBox6.Location = new System.Drawing.Point(677, 245);
            this.handPictureBox6.Name = "handPictureBox6";
            this.handPictureBox6.Size = new System.Drawing.Size(119, 178);
            this.handPictureBox6.TabIndex = 8;
            this.handPictureBox6.TabStop = false;
            // 
            // handPictureBox7
            // 
            this.handPictureBox7.Location = new System.Drawing.Point(802, 245);
            this.handPictureBox7.Name = "handPictureBox7";
            this.handPictureBox7.Size = new System.Drawing.Size(119, 178);
            this.handPictureBox7.TabIndex = 9;
            this.handPictureBox7.TabStop = false;
            // 
            // labelTurn
            // 
            this.labelTurn.AutoSize = true;
            this.labelTurn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTurn.Location = new System.Drawing.Point(394, 9);
            this.labelTurn.Name = "labelTurn";
            this.labelTurn.Size = new System.Drawing.Size(170, 25);
            this.labelTurn.TabIndex = 10;
            this.labelTurn.Text = "Computer\'s Turn";
            // 
            // buttonLeft
            // 
            this.buttonLeft.Location = new System.Drawing.Point(12, 324);
            this.buttonLeft.Name = "buttonLeft";
            this.buttonLeft.Size = new System.Drawing.Size(35, 23);
            this.buttonLeft.TabIndex = 11;
            this.buttonLeft.Text = "<";
            this.buttonLeft.UseVisualStyleBackColor = true;
            // 
            // buttonRight
            // 
            this.buttonRight.Location = new System.Drawing.Point(927, 324);
            this.buttonRight.Name = "buttonRight";
            this.buttonRight.Size = new System.Drawing.Size(35, 23);
            this.buttonRight.TabIndex = 12;
            this.buttonRight.Text = ">";
            this.buttonRight.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(974, 451);
            this.Controls.Add(this.buttonRight);
            this.Controls.Add(this.buttonLeft);
            this.Controls.Add(this.labelTurn);
            this.Controls.Add(this.handPictureBox7);
            this.Controls.Add(this.handPictureBox6);
            this.Controls.Add(this.handPictureBox5);
            this.Controls.Add(this.handPictureBox4);
            this.Controls.Add(this.handPictureBox3);
            this.Controls.Add(this.handPictureBox2);
            this.Controls.Add(this.labelHand);
            this.Controls.Add(this.handPictureBox1);
            this.Controls.Add(this.discardPictureBox);
            this.Controls.Add(this.deckPictureBox);
            this.Name = "Form1";
            this.Text = "Uno";
            ((System.ComponentModel.ISupportInitialize)(this.deckPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.discardPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.handPictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.handPictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.handPictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.handPictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.handPictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.handPictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.handPictureBox7)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox deckPictureBox;
        private System.Windows.Forms.PictureBox discardPictureBox;
        private System.Windows.Forms.PictureBox handPictureBox1;
        private System.Windows.Forms.Label labelHand;
        private System.Windows.Forms.PictureBox handPictureBox2;
        private System.Windows.Forms.PictureBox handPictureBox3;
        private System.Windows.Forms.PictureBox handPictureBox4;
        private System.Windows.Forms.PictureBox handPictureBox5;
        private System.Windows.Forms.PictureBox handPictureBox6;
        private System.Windows.Forms.PictureBox handPictureBox7;
        private System.Windows.Forms.Label labelTurn;
        private System.Windows.Forms.Button buttonLeft;
        private System.Windows.Forms.Button buttonRight;
    }
}

