﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUIProject
{
    class Card
    {

        public Image card;
        private string file_name;

        /// <summary>
        /// The constructor which allows us to instantiate a valid Card object.
        /// </summary>
        /// <param name="file">The name of card file.</param>
        public Card(string file)
        {
            card = Image.FromFile(file);
            file_name = file;
        }

        /// <summary>
        /// Displays a card in a picture box.
        /// </summary>
        /// <param name="card_path">The relative card path as a string.</param>
        /// <param name="box">The picture box in which to display the card.</param>
        public void displayCard(PictureBox box)
        {
            box.Image = card;
            box.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        /// <summary>
        /// Change what is displayed when ToString is called. 
        /// </summary>
        /// <returns>The file name for this card's image.</returns>
        public override string ToString()
        {
            return file_name;
        }

    }
}
