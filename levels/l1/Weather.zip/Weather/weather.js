//Updated to use Windy API V3 on 12th Jan 2024
function displayWeather(response){
    
}

function displayWebcams(response){

}

/**
 A function which handles a standard generic AJAX request.
 */
 function ajaxRequest(method, url, data, callback, header){
    let request = new XMLHttpRequest();
    request.open(method,url,true);

    //The new version of Windy API requires the key to be included in the header rather than URL
    if (header === true && method === "GET"){
        request.setRequestHeader('x-windy-api-key', '4ronM9soX5Cb3JiGv9OeqhD1Q1eihzZG');
    }
    
    if(method == "POST"){
        request.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
    }
    
    request.onreadystatechange = function(){
        if (request.readyState == 4) {
            if (request.status == 200) {
                let response = request.responseText.trim();
                callback(response);
            } else {
                //do nothing
            }
        }
    }
    request.send(data);
}

/**
  A function which makes an API AJAX request call to Open Weather Map.
 */
  function getWeather(){
    let city = document.getElementById("cityname").value;
    let url = "https://api.openweathermap.org/data/2.5/weather?&q=" + city + ",NZ&appid=91b9d19c154c7c262a7c1a46027ae13a&units=metric";
    ajaxRequest("GET",url,"", displayWeather, false);
}

/**
 A function which makes an API AJAX request call to Windy. 
 */
 function getWebcams(lat, long){
    let url = "https://api.windy.com/webcams/api/v3/webcams?lang=en&limit=10&offset=0&nearby=" + 
    lat + "," + long + ",10&include=images";
    ajaxRequest("GET",url,"", displayWebcams, true);
}
