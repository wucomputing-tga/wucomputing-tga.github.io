﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace ParkwayCommute
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            SqlConnection connection = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ParkwayCommute;Integrated Security=True");
            connection.Open();

            String query = "SELECT TravelMode, COUNT(TravelMode) as Commutes FROM TravelModes GROUP BY TravelMode";
            DataSet ds = getData(query, connection, "TravelModes");
            displayChart(chartTravelModes, ds, "TravelModes", "TravelMode", "Commutes", "Data by Travel Modes");

            query = "SELECT EmissionsType, COUNT(EmissionsType) as Emissions FROM TravelModes GROUP BY EmissionsType";
            ds = getData(query, connection, "Emissions");
            displayChart(chartEmissions, ds, "Emissions", "EmissionsType", "Emissions", "Data by Emissions");

            query = "SELECT AVG(ArriveTime), AVG(DepartTime) FROM Commutes";
            ds = getData(query, connection, "Times");
            DataRow row = ds.Tables[0].Rows[0];
            labelMornTimeTaken.Text += " " + row[0].ToString() + " minutes";
            labelEveningTimeTaken.Text += " " + row[1].ToString() + " minutes";

            query = "SELECT AVG(DATEPART(hour, ArriveBy)) as ArriveByHr FROM Commutes WHERE DATEPART(hour, ArriveBy) < 12";
            setTimeLabel(labelMornArrTime, query, connection);

            query = "SELECT AVG(DATEPART(hour, ArriveBy)) as ArriveByHr FROM Commutes WHERE DATEPART(hour, ArriveBy) > 12";
            setTimeLabel(labelEveningArrTime, query, connection);

            query = "SELECT AVG(DATEPART(hour, DepartBy)) as DepartByHr FROM Commutes WHERE DATEPART(hour, DepartBy) < 12";
            setTimeLabel(labelMornDepartTime, query, connection);

            query = "SELECT AVG(DATEPART(hour, DepartBy)) as DepartByHr FROM Commutes WHERE DATEPART(hour, DepartBy) > 12";
            setTimeLabel(labelEveningDepartTime, query, connection);


            /*foreach(DataTable table in dataset.Tables)
            {
                foreach(DataRow row in table.Rows)
                {
                    foreach(DataColumn column in table.Columns)
                    {
                        Console.WriteLine(row[column].ToString());
                    }
                }
            }*/
        }

        private void setTimeLabel(Label label, string query, SqlConnection connection)
        {
            DataSet ds = getData(query, connection, "Morning hour");
            DataRow row = ds.Tables[0].Rows[0];
            label.Text += " " + row[0].ToString().PadLeft(2, '0') + ":00";
        }

        private DataSet getData(string query, SqlConnection connection, string datasetName)
        {
            SqlCommand getTravelModes = new SqlCommand(query, connection);
            SqlDataAdapter adapter = new SqlDataAdapter(getTravelModes);
            DataSet dataset = new DataSet();
            adapter.Fill(dataset, datasetName);
            return dataset;
        }

        private void displayChart(Chart chart, DataSet dataset, string datasetName, string x, string y, string title)
        {
            chart.DataSource = dataset.Tables[datasetName];
            chart.Series[datasetName].XValueMember = x;
            chart.Series[datasetName].YValueMembers = y;
            chart.Titles.Add(title);
            chart.Series[datasetName].ChartType = SeriesChartType.Pie;
            chart.Series[datasetName].IsValueShownAsLabel = true;
        }

    }
}
