﻿namespace ParkwayCommute
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.chartTravelModes = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartEmissions = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.labelStats = new System.Windows.Forms.Label();
            this.labelMorning = new System.Windows.Forms.Label();
            this.labelEvening = new System.Windows.Forms.Label();
            this.labelMornDepartTime = new System.Windows.Forms.Label();
            this.labelEvenDepartTime = new System.Windows.Forms.Label();
            this.labelMornArrTime = new System.Windows.Forms.Label();
            this.labelMornTimeTaken = new System.Windows.Forms.Label();
            this.labelEveningTimeTaken = new System.Windows.Forms.Label();
            this.labelEveningArrTime = new System.Windows.Forms.Label();
            this.labelEveningDepartTime = new System.Windows.Forms.Label();
            this.labelEven = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartTravelModes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartEmissions)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(64, 64);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(82, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(266, 39);
            this.label1.TabIndex = 1;
            this.label1.Text = "Parkway Commute";
            // 
            // chartTravelModes
            // 
            chartArea1.Name = "ChartArea1";
            this.chartTravelModes.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chartTravelModes.Legends.Add(legend1);
            this.chartTravelModes.Location = new System.Drawing.Point(12, 108);
            this.chartTravelModes.Name = "chartTravelModes";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "TravelModes";
            this.chartTravelModes.Series.Add(series1);
            this.chartTravelModes.Size = new System.Drawing.Size(370, 300);
            this.chartTravelModes.TabIndex = 2;
            this.chartTravelModes.Text = "chart1";
            // 
            // chartEmissions
            // 
            chartArea2.Name = "ChartArea1";
            this.chartEmissions.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.chartEmissions.Legends.Add(legend2);
            this.chartEmissions.Location = new System.Drawing.Point(682, 108);
            this.chartEmissions.Name = "chartEmissions";
            this.chartEmissions.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Pastel;
            series2.ChartArea = "ChartArea1";
            series2.Legend = "Legend1";
            series2.Name = "Emissions";
            this.chartEmissions.Series.Add(series2);
            this.chartEmissions.Size = new System.Drawing.Size(370, 300);
            this.chartEmissions.TabIndex = 3;
            this.chartEmissions.Text = "chart1";
            // 
            // labelStats
            // 
            this.labelStats.AutoSize = true;
            this.labelStats.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelStats.Location = new System.Drawing.Point(479, 108);
            this.labelStats.Name = "labelStats";
            this.labelStats.Size = new System.Drawing.Size(115, 33);
            this.labelStats.TabIndex = 4;
            this.labelStats.Text = "Statistics";
            // 
            // labelMorning
            // 
            this.labelMorning.AutoSize = true;
            this.labelMorning.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMorning.Location = new System.Drawing.Point(404, 154);
            this.labelMorning.Name = "labelMorning";
            this.labelMorning.Size = new System.Drawing.Size(91, 26);
            this.labelMorning.TabIndex = 5;
            this.labelMorning.Text = "Morning:";
            // 
            // labelEvening
            // 
            this.labelEvening.AutoSize = true;
            this.labelEvening.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEvening.Location = new System.Drawing.Point(404, 273);
            this.labelEvening.Name = "labelEvening";
            this.labelEvening.Size = new System.Drawing.Size(0, 26);
            this.labelEvening.TabIndex = 6;
            // 
            // labelMornDepartTime
            // 
            this.labelMornDepartTime.AutoSize = true;
            this.labelMornDepartTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMornDepartTime.Location = new System.Drawing.Point(405, 189);
            this.labelMornDepartTime.Name = "labelMornDepartTime";
            this.labelMornDepartTime.Size = new System.Drawing.Size(123, 20);
            this.labelMornDepartTime.TabIndex = 7;
            this.labelMornDepartTime.Text = "Departure Time:";
            // 
            // labelEvenDepartTime
            // 
            this.labelEvenDepartTime.AutoSize = true;
            this.labelEvenDepartTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEvenDepartTime.Location = new System.Drawing.Point(405, 299);
            this.labelEvenDepartTime.Name = "labelEvenDepartTime";
            this.labelEvenDepartTime.Size = new System.Drawing.Size(0, 20);
            this.labelEvenDepartTime.TabIndex = 8;
            // 
            // labelMornArrTime
            // 
            this.labelMornArrTime.AutoSize = true;
            this.labelMornArrTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMornArrTime.Location = new System.Drawing.Point(405, 218);
            this.labelMornArrTime.Name = "labelMornArrTime";
            this.labelMornArrTime.Size = new System.Drawing.Size(94, 20);
            this.labelMornArrTime.TabIndex = 9;
            this.labelMornArrTime.Text = "Arrival Time:";
            // 
            // labelMornTimeTaken
            // 
            this.labelMornTimeTaken.AutoSize = true;
            this.labelMornTimeTaken.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMornTimeTaken.Location = new System.Drawing.Point(405, 247);
            this.labelMornTimeTaken.Name = "labelMornTimeTaken";
            this.labelMornTimeTaken.Size = new System.Drawing.Size(95, 20);
            this.labelMornTimeTaken.TabIndex = 10;
            this.labelMornTimeTaken.Text = "Time Taken:";
            // 
            // labelEveningTimeTaken
            // 
            this.labelEveningTimeTaken.AutoSize = true;
            this.labelEveningTimeTaken.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEveningTimeTaken.Location = new System.Drawing.Point(405, 376);
            this.labelEveningTimeTaken.Name = "labelEveningTimeTaken";
            this.labelEveningTimeTaken.Size = new System.Drawing.Size(95, 20);
            this.labelEveningTimeTaken.TabIndex = 14;
            this.labelEveningTimeTaken.Text = "Time Taken:";
            // 
            // labelEveningArrTime
            // 
            this.labelEveningArrTime.AutoSize = true;
            this.labelEveningArrTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEveningArrTime.Location = new System.Drawing.Point(405, 347);
            this.labelEveningArrTime.Name = "labelEveningArrTime";
            this.labelEveningArrTime.Size = new System.Drawing.Size(94, 20);
            this.labelEveningArrTime.TabIndex = 13;
            this.labelEveningArrTime.Text = "Arrival Time:";
            // 
            // labelEveningDepartTime
            // 
            this.labelEveningDepartTime.AutoSize = true;
            this.labelEveningDepartTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEveningDepartTime.Location = new System.Drawing.Point(405, 318);
            this.labelEveningDepartTime.Name = "labelEveningDepartTime";
            this.labelEveningDepartTime.Size = new System.Drawing.Size(123, 20);
            this.labelEveningDepartTime.TabIndex = 12;
            this.labelEveningDepartTime.Text = "Departure Time:";
            // 
            // labelEven
            // 
            this.labelEven.AutoSize = true;
            this.labelEven.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEven.Location = new System.Drawing.Point(404, 283);
            this.labelEven.Name = "labelEven";
            this.labelEven.Size = new System.Drawing.Size(85, 26);
            this.labelEven.TabIndex = 11;
            this.labelEven.Text = "Evening:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1064, 420);
            this.Controls.Add(this.labelEveningTimeTaken);
            this.Controls.Add(this.labelEveningArrTime);
            this.Controls.Add(this.labelEveningDepartTime);
            this.Controls.Add(this.labelEven);
            this.Controls.Add(this.labelMornTimeTaken);
            this.Controls.Add(this.labelMornArrTime);
            this.Controls.Add(this.labelEvenDepartTime);
            this.Controls.Add(this.labelMornDepartTime);
            this.Controls.Add(this.labelEvening);
            this.Controls.Add(this.labelMorning);
            this.Controls.Add(this.labelStats);
            this.Controls.Add(this.chartEmissions);
            this.Controls.Add(this.chartTravelModes);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartTravelModes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartEmissions)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartTravelModes;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartEmissions;
        private System.Windows.Forms.Label labelStats;
        private System.Windows.Forms.Label labelMorning;
        private System.Windows.Forms.Label labelEvening;
        private System.Windows.Forms.Label labelMornDepartTime;
        private System.Windows.Forms.Label labelEvenDepartTime;
        private System.Windows.Forms.Label labelMornArrTime;
        private System.Windows.Forms.Label labelMornTimeTaken;
        private System.Windows.Forms.Label labelEveningTimeTaken;
        private System.Windows.Forms.Label labelEveningArrTime;
        private System.Windows.Forms.Label labelEveningDepartTime;
        private System.Windows.Forms.Label labelEven;
    }
}

