#
# Licensed under 3-Clause BSD license available in the License file. Copyright (c) 2021-2022 iRobot Corporation. All rights reserved.
#

from irobot_edu_sdk.backend.bluetooth import Bluetooth
from irobot_edu_sdk.robots import event, hand_over, Color, Robot, Root, Create3
from irobot_edu_sdk.music import Note

robot = Create3(Bluetooth())  # Will connect to the first robot found.
#robot = Root(Bluetooth())


@event(robot.when_play)
async def dance(robot):
    while True:
        print('Lets dance')
        #find the dance floor and mark (0,0) once set to the robot's starting position
        await robot.navigate_to(16,16)
        await robot.navigate_to(0,0)
        #await robot.get_position()
        #example where robot drive to coordinate (16,16) and then back to (0,0)

#Try again - line by line for the Bob Marley song till perfection   

@event(robot.when_play)
async def sing(robot):
#'cause ev - ry lit -tle thinggggg
        await robot.play_note(391,0.40)
        await robot.play_note(659,0.15)
        await robot.play_note(659,0.15)
        await robot.play_note(659,0.15)
        await robot.play_note(659,0.15)

        await robot.play_note(659,1.30)
# gon -na be al -
        await robot.play_note(659,0.15)
        await robot.play_note(659,0.15)
        await robot.play_note(698,0.4)
        await robot.play_note(659,0.4)
# right ----
        await robot.play_note(590,1.0)

#    
       
robot.play()
#Improvement: change the dance moce choreography to rand()
#Insert guardrails, when bumped into a wall, move -16cm and start the recital again
#from the top

#What is the difference between when_touched and when_bumped
#@event(robot.when_touched,[True, False])
#async def when_touch_fl(robot):
#    await robot.play_note(F4, .125)
#    await robot.play_note(G4, .125)
#    await robot.play_note(A4, .125)

#@event(robot.when_bumped, [False, True]) # Right silence treatment trigger #Im always right"
#async def bumped(robot):
#    await robot.set_lights_on_rgb(255, 0, 0)
#    await robot.set_wheel_speeds(speed, -speed)
#    await robot.set_wheel_speeds(-speed, speed)