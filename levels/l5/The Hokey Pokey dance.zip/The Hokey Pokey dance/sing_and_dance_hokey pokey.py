#
# Licensed under 3-Clause BSD license available in the License file. Copyright (c) 2021-2022 iRobot Corporation. All rights reserved.
#

from irobot_edu_sdk.backend.bluetooth import Bluetooth
from irobot_edu_sdk.robots import event, hand_over, Color, Robot, Root, Create3
from irobot_edu_sdk.music import Note

robot = Create3(Bluetooth())  # Will connect to the first robot found.
#robot = Root(Bluetooth())


@event(robot.when_play)
async def dance(robot):
    while True:
        print('Lets dance')
        await robot.move(30)
        await robot.move(-30)
        await robot.move(30)

        await robot.turn_right(15)
        await robot.turn_left(15)
        await robot.turn_right(15)
        await robot.turn_left(15)
        await robot.turn_right(15)
        await robot.turn_left(15)
        await robot.turn_right(15)

        await robot.turn_right(360)

        for _ in range(4):
            await robot.move(5)
            await robot.move(5)
            
@event(robot.when_play)
async def sing(robot):
    notes = [
        #You put your
        (Note.C4, Note.HALF),
        (Note.D4, Note.QUARTER),
        (Note.C4, Note.QUARTER),
        #right foot in; You put your
        (Note.F4, Note.QUARTER),
        (Note.F4, Note.QUARTER),
        (Note.F4, Note.EIGHTH),
        (Note.C4, Note.EIGHTH),
        (Note.D4, Note.EIGHTH),
        (Note.C4, Note.EIGHTH),
        #right foot 
        (Note.F4, Note.QUARTER),
        (Note.F4, Note.QUARTER),
        #out; You put your
        (Note.F4, Note.EIGHTH),
        (Note.C4, Note.EIGHTH),
        (Note.D4, Note.EIGHTH),
        (Note.C4, Note.EIGHTH),
        #right foot in
        (Note.F4, Note.QUARTER),
        (Note.F4, Note.QUARTER),
        (Note.F4, Note.QUARTER),
        # And you shake it all about
        (Note.D4, Note.EIGHTH),
        (Note.C4, Note.EIGHTH),

        (Note.E4, Note.EIGHTH),
        (Note.D4_SHARP, Note.EIGHTH),
        (Note.E4, Note.EIGHTH),
        (Note.D4_SHARP, Note.EIGHTH),
        #about
        (Note.E4, Note.QUARTER),
        #You
        (Note.C4, Note.QUARTER),
        #do the Hok-ey
        (Note.E4, Note.EIGHTH),
        (Note.D4_SHARP, Note.EIGHTH),
        (Note.E4, Note.EIGHTH),
        (Note.D4_SHARP, Note.EIGHTH),
        #Pok-ey, And you
        (Note.E4, Note.EIGHTH),
        (Note.G4, Note.EIGHTH),
        (Note.D4, Note.EIGHTH),
        (Note.C4, Note.EIGHTH),

        #turn your - self a
        (Note.E4, Note.EIGHTH),
        (Note.D4_SHARP, Note.EIGHTH),
        (Note.E4, Note.EIGHTH),
        (Note.D4_SHARP, Note.EIGHTH),
        # - round
        (Note.E4, Note.WHOLE),

        #That's 
        (Note.C4, Note.WHOLE),
        #what its all
        (Note.C4, Note.EIGHTH),
        (Note.C4, Note.EIGHTH),
        (Note.D4, Note.QUARTER),

        #about
        (Note.E4, Note.WHOLE),
    ]
    while True:
        for note in notes:
            await robot.play_note(note[0], note[1])     
       
robot.play()
