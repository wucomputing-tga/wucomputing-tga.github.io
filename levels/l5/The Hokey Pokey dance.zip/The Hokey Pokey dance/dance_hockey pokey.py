#
# Licensed under 3-Clause BSD license available in the License file. Copyright (c) 2021-2022 iRobot Corporation. All rights reserved.
#

from irobot_edu_sdk.backend.bluetooth import Bluetooth
from irobot_edu_sdk.robots import event, hand_over, Color, Robot, Root, Create3
from irobot_edu_sdk.music import Note

robot = Create3(Bluetooth())  # Will connect to the first robot found.
#robot = Root(Bluetooth())


@event(robot.when_play)
async def dance(robot):
    while True:
        print('Lets dance')
        await robot.move(30)
        await robot.move(-30)
        await robot.move(30)

        await robot.turn_right(15)
        await robot.turn_left(15)
        await robot.turn_right(15)
        await robot.turn_left(15)
        await robot.turn_right(15)
        await robot.turn_left(15)
        await robot.turn_right(15)

        await robot.turn_right(360)

        for _ in range(4):
            await robot.move(5)
            await robot.move(5)
            
      
       
robot.play()
