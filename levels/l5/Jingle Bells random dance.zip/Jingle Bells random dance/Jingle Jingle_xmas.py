#
# Licensed under 3-Clause BSD license available in the License file. Copyright (c) 2021-2022 iRobot Corporation. All rights reserved.
#

from irobot_edu_sdk.backend.bluetooth import Bluetooth
from irobot_edu_sdk.robots import event, hand_over, Color, Robot, Root, Create3
from irobot_edu_sdk.music import Note

robot = Create3(Bluetooth())  # Will connect to the first robot found.
#robot = Root(Bluetooth())

#try rand()
@event(robot.when_play)
async def walk(robot):
    while True:
        print('Merry Xmas to you all')
        await robot.set_lights_rgb(0,255,0)
        await robot.move(6)
        await robot.turn_right(45)
        await robot.set_lights_rgb(255,0,0)
        await robot.move(-6)
        await robot.turn_left(45)
        await robot.move(6)
        await robot.turn_left(45)
        await robot.move(-6)
        await robot.turn_right(360)
        await robot.turn_right(360)
        await robot.turn_right(360)

#import random
# import random works, robotmove forward in random measuremen how to repeat for loop
# FOR LOOP doesnt work here not sure why, square/xmas tree dance
#    for_in range(4):
#        await robot.move(random.randrange(1,17))
#        await robot.turn(Direction.Right, 90)
#why backward doesnt work
#await robot.move(random.randrange(-1, -17))
# https://musescore.com/user/28416909/scores/9092570
#Chorus https://genius.com/Christmas-songs-jingle-bells-lyrics
# https://www.piano-keyboard-guide.com/how-to-play-jingle-bells-easy-piano-keyboard-tutorial-for-beginners/
@event(robot.when_play)
async def sing(robot):
#    notes = [
        #Oh! Jingle bells, jingle bells
        await robot.play_note(659, 0.2)
        await robot.play_note(659, 0.2)
        await robot.play_note(659, 0.4)
        
        await robot.play_note(659, 0.2)
        await robot.play_note(659, 0.2)
        await robot.play_note(659, 0.4)

        #Jingle all the way
        await robot.play_note(659, 0.2)
        await robot.play_note(783, 0.2)
        await robot.play_note(523, 0.2)
        await robot.play_note(587, 0.2)
        await robot.play_note(659, 0.4)
        
        
        #Oh, what fun  it is to ride
        await robot.play_note(698,0.2)
        await robot.play_note(698,0.2)
        await robot.play_note(698,0.2)
        await robot.play_note(698,0.2)
        await robot.play_note(698,0.2)
        await robot.play_note(659,0.2)
        await robot.play_note(659,0.2)
        await robot.play_note(659,0.2)

        #In a one-horse open sleigh, hey
        await robot.play_note(587,0.2)
        await robot.play_note(587,0.2)
        await robot.play_note(659,0.2)
        await robot.play_note(587,0.2)
        await robot.play_note(783,0.4)

        #Oh! Jingle bells, jingle bells
        await robot.play_note(659, 0.2)
        await robot.play_note(659, 0.2)
        await robot.play_note(659, 0.4)

        await robot.play_note(659, 0.2)
        await robot.play_note(659, 0.2)
        await robot.play_note(659, 0.4)

        #Jingle all the way
        await robot.play_note(659, 0.2)
        await robot.play_note(783, 0.2)
        await robot.play_note(523, 0.2)
        await robot.play_note(587, 0.2)
        await robot.play_note(659, 0.4)

        #Oh, what fun  it is to ride
        await robot.play_note(698,0.2)
        await robot.play_note(698,0.2)
        await robot.play_note(698,0.2)
        await robot.play_note(698,0.2)
        await robot.play_note(698,0.2)
        await robot.play_note(659,0.2)
        await robot.play_note(659,0.2)
        await robot.play_note(659,0.2)

        #In a one-horse open sleigh, hey
        await robot.play_note(783,0.2)
        await robot.play_note(783,0.2)
        await robot.play_note(698,0.2)
        await robot.play_note(587,0.2)
        await robot.play_note(523,0.4)

await robot.stop()

robot.play()
